-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Sep 18, 2018 at 08:43 AM
-- Server version: 5.0.41
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `gardencity`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `accounts`
-- 

CREATE TABLE `accounts` (
  `id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `amount` decimal(19,4) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `accounts`
-- 

INSERT INTO `accounts` (`id`, `name`, `amount`) VALUES 
(1, 'eugene', 5000.0000),
(2, 'gregory', 10.0000);

-- --------------------------------------------------------

-- 
-- Table structure for table `bank`
-- 

CREATE TABLE `bank` (
  `customerID` int(15) NOT NULL,
  `name` varchar(15) NOT NULL,
  `balance` double NOT NULL,
  PRIMARY KEY  (`customerID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `bank`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `customers`
-- 

CREATE TABLE `customers` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') default '1',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=676768 ;

-- 
-- Dumping data for table `customers`
-- 

INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `created`, `modified`, `status`) VALUES 
(676767, 'eugene', 'eugenemuthini@gmail.com', '0701058156', '54 makueni', '2014-12-16 09:49:53', '2017-04-18 09:50:05', '1');

-- --------------------------------------------------------

-- 
-- Table structure for table `details`
-- 

CREATE TABLE `details` (
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(65) NOT NULL,
  `amount` double NOT NULL,
  PRIMARY KEY  (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `details`
-- 

INSERT INTO `details` (`name`, `email`, `password`, `amount`) VALUES 
('eryson', 'eryson@gmail.com', '25d55ad283aa400af464c76d713c07ad', 1999300),
('eugene', 'eugenemuthini@gmail.', '81149e4ccca4c102e5b5fb19b9b2ed9c', 2000000),
('eugene', 'eugine@gmail.com', 'f638f4354ff089323d1a5f78fd8f63ca', 1999200),
('francis', 'francis@gmail.com', 'dc0fa7df3d07904a09288bd2d2bb5f40', 1999300);

-- --------------------------------------------------------

-- 
-- Table structure for table `li_ajax_post_load`
-- 

CREATE TABLE `li_ajax_post_load` (
  `post_id` int(11) NOT NULL,
  `post_title` varchar(250) NOT NULL,
  `post_desc` text NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY  (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `li_ajax_post_load`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `orders`
-- 

CREATE TABLE `orders` (
  `id` int(11) NOT NULL auto_increment,
  `customer_id` int(11) NOT NULL,
  `total_price` float(10,2) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=297 ;

-- 
-- Dumping data for table `orders`
-- 

INSERT INTO `orders` (`id`, `customer_id`, `total_price`, `created`, `modified`, `status`) VALUES 
(278, 1, 150.00, '2017-06-24 15:28:38', '2017-06-24 15:28:38', '1'),
(279, 1, 9300.00, '2017-06-24 15:31:59', '2017-06-24 15:31:59', '1'),
(280, 1, 465.00, '2017-06-24 15:36:12', '2017-06-24 15:36:12', '1'),
(281, 1, 340.00, '2017-10-05 15:39:14', '2017-10-05 15:39:15', '1'),
(282, 1, 4900.00, '2017-11-11 08:37:04', '2017-11-11 08:37:04', '1'),
(283, 1, 400.00, '2017-11-11 08:38:23', '2017-11-11 08:38:23', '1'),
(284, 1, 460.00, '2017-12-05 14:45:40', '2017-12-05 14:45:40', '1'),
(285, 1, 465.00, '2017-12-08 18:42:01', '2017-12-08 18:42:01', '1'),
(286, 1, 150.00, '2017-12-08 18:42:17', '2017-12-08 18:42:17', '1'),
(287, 1, 5175.00, '2017-12-28 18:08:14', '2017-12-28 18:08:14', '1'),
(288, 1, 4800.00, '2017-12-28 18:09:06', '2017-12-28 18:09:06', '1'),
(289, 1, 140.00, '2017-12-28 18:12:17', '2017-12-28 18:12:17', '1'),
(290, 1, 300.00, '2017-12-29 15:21:21', '2017-12-29 15:21:21', '1'),
(291, 1, 700.00, '2018-01-18 13:36:41', '2018-01-18 13:36:41', '1'),
(292, 1, 800.00, '2018-05-22 12:32:07', '2018-05-22 12:32:07', '1'),
(293, 1, 700.00, '2018-06-04 11:09:46', '2018-06-04 11:09:46', '1'),
(294, 1, 700.00, '2018-06-12 22:18:45', '2018-06-12 22:18:45', '1'),
(295, 1, 500.00, '2018-06-26 22:18:43', '2018-06-26 22:18:43', '1'),
(296, 1, 300.00, '2018-06-26 22:29:45', '2018-06-26 22:29:45', '1');

-- --------------------------------------------------------

-- 
-- Table structure for table `order_items`
-- 

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL auto_increment,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(5) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=257 ;

-- 
-- Dumping data for table `order_items`
-- 

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`) VALUES 
(222, 278, 1130, 1),
(223, 279, 1132, 2),
(224, 279, 1133, 1),
(225, 280, 1133, 1),
(226, 280, 1122, 1),
(227, 281, 1131, 1),
(228, 281, 1123, 1),
(229, 282, 1132, 1),
(230, 282, 1131, 2),
(231, 283, 1131, 2),
(232, 284, 1121, 1),
(233, 284, 1133, 1),
(234, 285, 1121, 1),
(235, 285, 1122, 1),
(236, 285, 1123, 1),
(237, 286, 1130, 1),
(238, 287, 1130, 2),
(239, 287, 1129, 1),
(240, 287, 1132, 1),
(241, 287, 1133, 1),
(242, 288, 1132, 1),
(243, 288, 1133, 1),
(244, 289, 1125, 1),
(245, 290, 1133, 1),
(246, 291, 1131, 2),
(247, 291, 1133, 1),
(248, 292, 1131, 1),
(249, 292, 1133, 2),
(250, 293, 1131, 2),
(251, 293, 1133, 1),
(252, 294, 1131, 2),
(253, 294, 1133, 1),
(254, 295, 1131, 1),
(255, 295, 1133, 1),
(256, 296, 1133, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `products`
-- 

CREATE TABLE `products` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `price` float(10,2) unsigned NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `quantity` int(10) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1134 ;

-- 
-- Dumping data for table `products`
-- 

INSERT INTO `products` (`id`, `name`, `description`, `price`, `created`, `modified`, `quantity`) VALUES 
(1112, 'sugar', '2 KG', 380.00, '2017-05-15 10:02:09', '2017-05-16 10:02:12', 27),
(1113, 'bathing soap', '500 GRAMS', 170.00, '2017-05-15 10:03:00', '2017-05-16 10:03:05', 11),
(1114, '0M0', '500 GRAMS', 150.00, '2017-05-22 10:03:34', '2017-05-24 10:03:39', 1),
(1115, 'brookside milk', '500 grams', 60.00, '2017-05-22 10:04:25', '2017-05-24 10:04:30', 12),
(1116, 'maize flour', '2 kg', 135.00, '2017-05-15 10:05:16', '2017-05-16 10:05:20', 11),
(1117, 'cooking oil', '1 litre', 250.00, '2017-05-25 10:06:53', '2017-05-26 10:06:57', 1),
(1118, 'weetabix', '500 grams', 180.00, '2017-05-29 10:07:47', '2017-05-30 10:07:51', 1),
(1119, 'cornflakes', '150 grams', 80.00, '2017-05-22 10:08:41', '2017-05-23 10:08:45', 1),
(1120, 'crisps', '150grams', 73.00, '2017-05-23 10:09:22', '2017-05-24 10:09:26', 1),
(1121, 'aerial washing powder', '500 grams', 160.00, '2017-05-22 10:11:03', '2017-05-23 10:11:09', 1),
(1122, 'sunlight washing powder', '500 grams', 165.00, '2017-05-22 10:12:16', '2017-05-23 10:12:20', 1),
(1123, 'soda', '10', 140.00, '2017-01-09 09:09:17', '2017-01-09 09:09:20', 20),
(1125, 'bread', '2 kg', 140.00, '2017-01-09 09:09:17', '2017-01-09 09:09:20', 4),
(1127, 'tea leaves', '3kg', 45.00, '2017-05-30 15:51:12', '2017-05-31 15:51:16', 4),
(1129, 'chocolate', '500gms', 75.00, '2014-12-16 09:49:53', '2017-05-31 15:51:16', 4),
(1130, 'omo', '500 grams', 150.00, '2017-01-09 09:09:17', '2017-01-09 09:09:20', 20),
(1131, 'cowboy', '500 gms', 200.00, '2017-08-07 11:12:45', '2017-04-11 09:51:23', 7),
(1132, 'ampex woofer', '400 kilowatts', 4500.00, '2017-08-08 09:09:09', '2017-05-31 15:51:16', 8),
(1133, 'blue band', '500gms', 300.00, '2017-05-23 15:50:08', '2017-11-11 12:12:10', 4);
